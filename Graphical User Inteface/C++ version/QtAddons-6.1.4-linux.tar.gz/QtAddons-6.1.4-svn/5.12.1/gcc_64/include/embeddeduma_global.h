#ifndef EMBEDDEDUMA_GLOBAL_H
#define EMBEDDEDUMA_GLOBAL_H

#include <QtCore/QtGlobal>

#if defined(QTEMBEDDEDUMA_LIBRARY)
#    define QCP_EXPORT Q_DECL_EXPORT
#elif defined(QTCOLORWIDGETS_STATICALLY_LINKED)
#    define QCP_EXPORT
#else
#    define QCP_EXPORT Q_DECL_IMPORT
#endif

#endif // EMBEDDEDUMA_GLOBAL_H
