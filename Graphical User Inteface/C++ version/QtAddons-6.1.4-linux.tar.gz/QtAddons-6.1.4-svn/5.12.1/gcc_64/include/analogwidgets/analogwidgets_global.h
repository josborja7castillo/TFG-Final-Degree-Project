#ifndef ANALOGWIDGETS_GLOBAL_H
#define ANALOGWIDGETS_GLOBAL_H

#include <QtCore/QtGlobal>

#if defined(QTANALOGWIDGETS_LIBRARY)
#    define QCP_EXPORT Q_DECL_EXPORT
#else
#    define QCP_EXPORT Q_DECL_IMPORT
#endif

#endif // EMBEDDEDUMA_GLOBAL_H
