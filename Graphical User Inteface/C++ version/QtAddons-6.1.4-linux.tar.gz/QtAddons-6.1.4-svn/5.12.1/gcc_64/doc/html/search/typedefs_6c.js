var searchData=
[
  ['legendattributes',['LegendAttributes',['../class_qwt_polar_curve.html#ac52b0fb483eb1114bc09328634faf641',1,'QwtPolarCurve']]]
];
