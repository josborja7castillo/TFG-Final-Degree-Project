var searchData=
[
  ['widgetkeypressevent',['widgetKeyPressEvent',['../class_qwt_polar_magnifier.html#a5276d05e09936f608d6e7d06d5f58ace',1,'QwtPolarMagnifier']]],
  ['widgetmousepressevent',['widgetMousePressEvent',['../class_qwt_polar_panner.html#a1e904467ed89354c473e228082464bc4',1,'QwtPolarPanner']]]
];
